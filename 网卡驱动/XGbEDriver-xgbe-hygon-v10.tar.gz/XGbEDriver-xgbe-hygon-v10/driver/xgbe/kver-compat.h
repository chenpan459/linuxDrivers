/* SPDX-License-Identifier: GPL-2.0 */

#ifndef __KVER_COMPAT_H__
#define __KVER_COMPAT_H__

#ifndef LINUX_VERSION_CODE
#include <linux/version.h>
#else
#define KERNEL_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + (c))
#endif
#include <linux/io.h>
#include <linux/delay.h>
#include <linux/errno.h>
#include <linux/etherdevice.h>
#include <linux/ethtool.h>
#include <linux/if_vlan.h>
#include <linux/in.h>
#include <linux/if_link.h>
#include <linux/init.h>
#include <linux/ioport.h>
#include <linux/ip.h>
#include <linux/ipv6.h>
#include <linux/list.h>
#include <linux/mii.h>
#include <linux/phy.h>
#include <linux/module.h>
#include <linux/netdevice.h>
#include <linux/pci.h>
#include <linux/sched.h>
#include <linux/skbuff.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/tcp.h>
#include <linux/types.h>
#include <linux/udp.h>

#ifndef GCC_VERSION
#define GCC_VERSION (__GNUC__ * 10000		\
		     + __GNUC_MINOR__ * 100	\
		     + __GNUC_PATCHLEVEL__)
#endif /* GCC_VERSION */

/* Backport macros for controlling GCC diagnostics */
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,18,0))

/* Compilers before gcc-4.6 do not understand "#pragma GCC diagnostic push" */
#if GCC_VERSION >= 40600
#define __diag_str1(s)		#s
#define __diag_str(s)		__diag_str1(s)
#define __diag(s)		_Pragma(__diag_str(GCC diagnostic s))
#else
#define __diag(s)
#endif /* GCC_VERSION >= 4.6 */
#define __diag_push()	__diag(push)
#define __diag_pop()	__diag(pop)

#if GCC_VERSION >= 70500
#define snprintf(buf, size, fmt, args...) _kc_snprintf(buf, size, fmt, ##args)
static inline int _kc_snprintf(char *buf, size_t size, const char *fmt, ...)
{
	int length;
	va_list args;

	__diag_push();
	__diag(ignored "-Wformat-truncation");

	va_start(args, fmt);
	length = vsnprintf(buf, size, fmt, args);
	va_end(args);

	__diag_pop();

	return (length);
}
#endif /* GCC_VERSION >= 7.5 */
#endif /* LINUX_VERSION < 4.18.0 */

#ifndef NSEC_PER_MSEC
#define NSEC_PER_MSEC 1000000L
#endif
#include <net/ipv6.h>
/* UTS_RELEASE is in a different header starting in kernel 2.6.18 */
#ifndef UTS_RELEASE
/* utsrelease.h changed locations in 2.6.33 */
#if ( LINUX_VERSION_CODE < KERNEL_VERSION(2,6,33) )
#include <linux/utsrelease.h>
#else
#include <generated/utsrelease.h>
#endif
#endif

#ifdef GCC_VERSION
#if ( GCC_VERSION < 3000 )
#define _Bool char
#endif
#else
#define _Bool char
#endif

#ifndef BIT
#define BIT(nr)         (1UL << (nr))
#endif

#undef __always_unused
#define __always_unused __attribute__((__unused__))

#undef __maybe_unused
#define __maybe_unused __attribute__((__unused__))

#ifndef module_param
#define module_param(v,t,p) MODULE_PARM(v, "i");
#endif

#ifndef __read_mostly
#define __read_mostly
#endif

#ifndef unlikely
#define unlikely(_x) _x
#define likely(_x) _x
#endif

#ifndef WARN_ON
#define WARN_ON(x)
#endif

#ifndef PCI_DEVICE
#define PCI_DEVICE(vend,dev) \
	.vendor = (vend), .device = (dev), \
	.subvendor = PCI_ANY_ID, .subdevice = PCI_ANY_ID
#endif

#ifndef node_online
#define node_online(node) ((node) == 0)
#endif

#ifndef cpu_online
#define cpu_online(cpuid) test_bit((cpuid), &cpu_online_map)
#endif

#ifndef _LINUX_RANDOM_H
#include <linux/random.h>
#endif

#ifndef BITS_PER_TYPE
#define BITS_PER_TYPE(type) (sizeof(type) * BITS_PER_BYTE)
#endif

#ifndef BITS_TO_LONGS
#define BITS_TO_LONGS(bits) (((bits)+BITS_PER_LONG-1)/BITS_PER_LONG)
#endif

#ifndef DECLARE_BITMAP
#define DECLARE_BITMAP(name,bits) long name[BITS_TO_LONGS(bits)]
#endif

#ifndef CONFIG_HAVE_EFFICIENT_UNALIGNED_ACCESS
#if defined(__i386__) || defined(__x86_64__)
#define CONFIG_HAVE_EFFICIENT_UNALIGNED_ACCESS
#endif
#endif

/* taken from 2.6.24 definition in linux/kernel.h */
#ifndef IS_ALIGNED
#define IS_ALIGNED(x,a)         (((x) % ((typeof(x))(a))) == 0)
#endif

#ifndef RHEL_RELEASE_VERSION
#define RHEL_RELEASE_VERSION(a,b) (((a) << 8) + (b))
#endif

#ifndef RHEL_RELEASE_CODE
/* NOTE: RHEL_RELEASE_* introduced in RHEL4.5 */
#define RHEL_RELEASE_CODE 0
#endif

/* RHEL 7 didn't backport the parameter change in
 * create_singlethread_workqueue.
 * If/when RH corrects this we will want to tighten up the version check.
 */
#if (RHEL_RELEASE_CODE && RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,0))
#undef create_singlethread_workqueue
#define create_singlethread_workqueue(name)	\
	alloc_ordered_workqueue("%s", WQ_MEM_RECLAIM, name)
#endif

/* Ubuntu Release ABI is the 4th digit of their kernel version. You can find
 * it in /usr/src/linux/$(uname -r)/include/generated/utsrelease.h for new
 * enough versions of Ubuntu. Otherwise you can simply see it in the output of
 * uname as the 4th digit of the kernel. The UTS_UBUNTU_RELEASE_ABI is not in
 * the linux-source package, but in the linux-headers package. It begins to
 * appear in later releases of 14.04 and 14.10.
 *
 * Ex:
 * <Ubuntu 14.04.1>
 *  $uname -r
 *  3.13.0-45-generic
 * ABI is 45
 *
 * <Ubuntu 14.10>
 *  $uname -r
 *  3.16.0-23-generic
 * ABI is 23
 */
#ifndef UTS_UBUNTU_RELEASE_ABI
#define UTS_UBUNTU_RELEASE_ABI 0
#define UBUNTU_VERSION_CODE 0
#else
/* Ubuntu does not provide actual release version macro, so we use the kernel
 * version plus the ABI to generate a unique version code specific to Ubuntu.
 * In addition, we mask the lower 8 bits of LINUX_VERSION_CODE in order to
 * ignore differences in sublevel which are not important since we have the
 * ABI value. Otherwise, it becomes impossible to correlate ABI to version for
 * ordering checks.
 */
#define UBUNTU_VERSION_CODE (((~0xFF & LINUX_VERSION_CODE) << 8) + \
			     UTS_UBUNTU_RELEASE_ABI)

#if UTS_UBUNTU_RELEASE_ABI > 255
#error UTS_UBUNTU_RELEASE_ABI is too large...
#endif /* UTS_UBUNTU_RELEASE_ABI > 255 */

#if ( LINUX_VERSION_CODE <= KERNEL_VERSION(3,0,0) )
/* Our version code scheme does not make sense for non 3.x or newer kernels,
 * and we have no support in kcompat for this scenario. Thus, treat this as a
 * non-Ubuntu kernel. Possibly might be better to error here.
 */
#define UTS_UBUNTU_RELEASE_ABI 0
#define UBUNTU_VERSION_CODE 0
#endif

#endif

/* Note that the 3rd digit is always zero, and will be ignored. This is
 * because Ubuntu kernels are based on x.y.0-ABI values, and while their linux
 * version codes are 3 digit, this 3rd digit is superseded by the ABI value.
 */
#define UBUNTU_VERSION(a,b,c,d) ((KERNEL_VERSION(a,b,0) << 8) + (d))

/* SuSE version macros are the same as Linux kernel version macro */
#ifndef SLE_VERSION
#define SLE_VERSION(a,b,c)	KERNEL_VERSION(a,b,c)
#endif
#define SLE_LOCALVERSION(a,b,c)	KERNEL_VERSION(a,b,c)
#ifdef CONFIG_SUSE_KERNEL
#if ( LINUX_VERSION_CODE == KERNEL_VERSION(2,6,27) )
/* SLES11 GA is 2.6.27 based */
#define SLE_VERSION_CODE SLE_VERSION(11,0,0)
#elif ( LINUX_VERSION_CODE == KERNEL_VERSION(2,6,32) )
/* SLES11 SP1 is 2.6.32 based */
#define SLE_VERSION_CODE SLE_VERSION(11,1,0)
#elif ( LINUX_VERSION_CODE == KERNEL_VERSION(3,0,13) )
/* SLES11 SP2 GA is 3.0.13-0.27 */
#define SLE_VERSION_CODE SLE_VERSION(11,2,0)
#elif ((LINUX_VERSION_CODE == KERNEL_VERSION(3,0,76)))
/* SLES11 SP3 GA is 3.0.76-0.11 */
#define SLE_VERSION_CODE SLE_VERSION(11,3,0)
#elif (LINUX_VERSION_CODE == KERNEL_VERSION(3,0,101))
  #if (SLE_LOCALVERSION_CODE < SLE_LOCALVERSION(0,8,0))
  /* some SLES11sp2 update kernels up to 3.0.101-0.7.x */
  #define SLE_VERSION_CODE SLE_VERSION(11,2,0)
  #elif (SLE_LOCALVERSION_CODE < SLE_LOCALVERSION(63,0,0))
  /* most SLES11sp3 update kernels */
  #define SLE_VERSION_CODE SLE_VERSION(11,3,0)
  #else
  /* SLES11 SP4 GA (3.0.101-63) and update kernels 3.0.101-63+ */
  #define SLE_VERSION_CODE SLE_VERSION(11,4,0)
  #endif
#elif (LINUX_VERSION_CODE == KERNEL_VERSION(3,12,28))
/* SLES12 GA is 3.12.28-4
 * kernel updates 3.12.xx-<33 through 52>[.yy] */
#define SLE_VERSION_CODE SLE_VERSION(12,0,0)
#elif (LINUX_VERSION_CODE == KERNEL_VERSION(3,12,49))
/* SLES12 SP1 GA is 3.12.49-11
 * updates 3.12.xx-60.yy where xx={51..} */
#define SLE_VERSION_CODE SLE_VERSION(12,1,0)
#elif ((LINUX_VERSION_CODE >= KERNEL_VERSION(4,4,21) && \
       (LINUX_VERSION_CODE <= KERNEL_VERSION(4,4,59))) || \
       (LINUX_VERSION_CODE >= KERNEL_VERSION(4,4,74) && \
        LINUX_VERSION_CODE < KERNEL_VERSION(4,5,0) && \
        SLE_LOCALVERSION_CODE >= KERNEL_VERSION(92,0,0) && \
        SLE_LOCALVERSION_CODE <  KERNEL_VERSION(93,0,0)))
/* SLES12 SP2 GA is 4.4.21-69.
 * SLES12 SP2 updates before SLES12 SP3 are: 4.4.{21,38,49,59}
 * SLES12 SP2 updates after SLES12 SP3 are: 4.4.{74,90,103,114,120}
 * but they all use a SLE_LOCALVERSION_CODE matching 92.nn.y */
#define SLE_VERSION_CODE SLE_VERSION(12,2,0)
#elif ((LINUX_VERSION_CODE == KERNEL_VERSION(4,4,73) || \
        LINUX_VERSION_CODE == KERNEL_VERSION(4,4,82) || \
        LINUX_VERSION_CODE == KERNEL_VERSION(4,4,92)) || \
       (LINUX_VERSION_CODE == KERNEL_VERSION(4,4,103) && \
       (SLE_LOCALVERSION_CODE == KERNEL_VERSION(6,33,0) || \
        SLE_LOCALVERSION_CODE == KERNEL_VERSION(6,38,0))) || \
       (LINUX_VERSION_CODE >= KERNEL_VERSION(4,4,114) && \
        LINUX_VERSION_CODE < KERNEL_VERSION(4,5,0) && \
        SLE_LOCALVERSION_CODE >= KERNEL_VERSION(94,0,0) && \
        SLE_LOCALVERSION_CODE <  KERNEL_VERSION(95,0,0)) )
/* SLES12 SP3 GM is 4.4.73-5 and update kernels are 4.4.82-6.3.
 * SLES12 SP3 updates not conflicting with SP2 are: 4.4.{82,92}
 * SLES12 SP3 updates conflicting with SP2 are:
 *   - 4.4.103-6.33.1, 4.4.103-6.38.1
 *   - 4.4.{114,120}-94.nn.y */
#define SLE_VERSION_CODE SLE_VERSION(12,3,0)
#elif (LINUX_VERSION_CODE == KERNEL_VERSION(4,12,14) && \
       (SLE_LOCALVERSION_CODE == KERNEL_VERSION(94,41,0) || \
       (SLE_LOCALVERSION_CODE >= KERNEL_VERSION(95,0,0) && \
        SLE_LOCALVERSION_CODE < KERNEL_VERSION(96,0,0))))
/* SLES12 SP4 GM is 4.12.14-94.41 and update kernel is 4.12.14-95.x. */
#define SLE_VERSION_CODE SLE_VERSION(12,4,0)
#elif (LINUX_VERSION_CODE == KERNEL_VERSION(4,12,14) && \
       (SLE_LOCALVERSION_CODE == KERNEL_VERSION(23,0,0) || \
        SLE_LOCALVERSION_CODE == KERNEL_VERSION(2,0,0) || \
        SLE_LOCALVERSION_CODE == KERNEL_VERSION(136,0,0) || \
        (SLE_LOCALVERSION_CODE >= KERNEL_VERSION(25,0,0) && \
	 SLE_LOCALVERSION_CODE < KERNEL_VERSION(26,0,0)) || \
	(SLE_LOCALVERSION_CODE >= KERNEL_VERSION(150,0,0) && \
	 SLE_LOCALVERSION_CODE < KERNEL_VERSION(151,0,0))))
/* SLES15 Beta1 is 4.12.14-2
 * SLES15 GM is 4.12.14-23 and update kernel is 4.12.14-{25,136},
 * and 4.12.14-150.14.
 */
#define SLE_VERSION_CODE SLE_VERSION(15,0,0)
#elif (LINUX_VERSION_CODE == KERNEL_VERSION(4,12,14) && \
       SLE_LOCALVERSION_CODE >= KERNEL_VERSION(25,23,0))
/* SLES15 SP1 Beta1 is 4.12.14-25.23 */
#define SLE_VERSION_CODE SLE_VERSION(15,1,0)
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(5,3,13))
/* SLES15 SP2 Beta1 is 5.3.13 */
#define SLE_VERSION_CODE SLE_VERSION(15,2,0)

/* new SLES kernels must be added here with >= based on kernel
 * the idea is to order from newest to oldest and just catch all
 * of them using the >=
 */
#endif /* LINUX_VERSION_CODE == KERNEL_VERSION(x,y,z) */
#endif /* CONFIG_SUSE_KERNEL */
#ifndef SLE_VERSION_CODE
#define SLE_VERSION_CODE 0
#endif /* SLE_VERSION_CODE */
#ifndef SLE_LOCALVERSION_CODE
#define SLE_LOCALVERSION_CODE 0
#endif /* SLE_LOCALVERSION_CODE */

/*
 * ADQ depends on __TC_MQPRIO_MODE_MAX and related kernel code
 * added around 4.15. Some distributions (e.g. Oracle Linux 7.7)
 * have done a partial back-port of that to their kernels based
 * on older mainline kernels that did not include all the necessary
 * kernel enablement to support ADQ.
 * Undefine __TC_MQPRIO_MODE_MAX for all OSV distributions with
 * kernels based on mainline kernels older than 4.15 except for
 * RHEL, SLES and Ubuntu which are known to have good back-ports.
 */
#if (!RHEL_RELEASE_CODE && !SLE_VERSION_CODE && !UBUNTU_VERSION_CODE)
  #if (LINUX_VERSION_CODE < KERNEL_VERSION(4,15,0))
  #undef __TC_MQPRIO_MODE_MAX
  #endif /*  LINUX_VERSION_CODE == KERNEL_VERSION(4,15,0) */
#endif /* if (NOT RHEL && NOT SLES && NOT UBUNTU) */

#ifdef CONFIG_DYNAMIC_DEBUG
#undef dev_dbg
#define dev_dbg(dev, format, arg...) dev_printk(KERN_DEBUG, dev, format, ##arg)
#undef pr_debug
#define pr_debug(format, arg...) printk(KERN_DEBUG format, ##arg)
#endif /* CONFIG_DYNAMIC_DEBUG */

/* Older versions of GCC will trigger -Wformat-nonliteral warnings for const
 * char * strings. Unfortunately, the implementation of do_trace_printk does
 * this, in order to add a storage attribute to the memory. This was fixed in
 * GCC 5.1, but we still use older distributions built with GCC 4.x.
 *
 * The string pointer is only passed as a const char * to the __trace_bprintk
 * function. Since that function has the __printf attribute, it will trigger
 * the warnings. We can't remove the attribute, so instead we'll use the
 * __diag macro to disable -Wformat-nonliteral around the call to
 * __trace_bprintk.
 */
#if GCC_VERSION < 50100
#define __trace_bprintk(ip, fmt, args...) ({		\
	int err;					\
	__diag_push();					\
	__diag(ignored "-Wformat-nonliteral");		\
	err = __trace_bprintk(ip, fmt, ##args);		\
	__diag_pop();					\
	err;						\
})
#endif /* GCC_VERSION < 5.1.0 */

/* Newer kernels removed <linux/pci-aspm.h> */
#if ((LINUX_VERSION_CODE < KERNEL_VERSION(5,4,0)) && \
     (RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(8,3)))
#define HAVE_PCI_ASPM_H
#endif

#ifndef HAVE_PCI_SET_MWI
#define pci_set_mwi(X) pci_write_config_word(X, \
			       PCI_COMMAND, adapter->hw.bus.pci_cmd_word | \
			       PCI_COMMAND_INVALIDATE);
#define pci_clear_mwi(X) pci_write_config_word(X, \
			       PCI_COMMAND, adapter->hw.bus.pci_cmd_word & \
			       ~PCI_COMMAND_INVALIDATE);
#endif

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,6,31))
#else /* < 2.6.31 */
#include <linux/mdio.h>
#endif /* < 2.6.31 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,6,39))

#else /* < 2.6.39 */
#ifndef HAVE_SETUP_TC
#define HAVE_SETUP_TC
#endif
#endif /* < 2.6.39 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3,0,0)) || \
    (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(6,4))
#if !defined(NO_PTP_SUPPORT) && IS_ENABLED(CONFIG_PTP_1588_CLOCK)
#define HAVE_PTP_1588_CLOCK
#endif /* !NO_PTP_SUPPORT && IS_ENABLED(CONFIG_PTP_1588_CLOCK) */
#endif /* >= 3.0.0 || RHEL_RELEASE > 6.4 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,2,0))
#else /* < 3.2.0 */
#ifndef HAVE_SKB_L4_RXHASH
#define HAVE_SKB_L4_RXHASH
#endif
#endif /* < 3.2.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,10,0))
#else /* >= 3.10.0 */
#if (RHEL_RELEASE_CODE && \
     (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,0)))
#if (RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(8,0))
#if (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,4))
#define HAVE_RHEL7_NETDEV_OPS_EXT_NDO_UDP_TUNNEL
#define HAVE_UDP_ENC_RX_OFFLOAD
#endif /* RHEL >= 7.4 */
#endif /* RHEL >= 8.0 */
#endif /* RHEL >= 7.0 */
#endif /* >= 3.10.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,11,0))
#define netdev_notifier_info_to_dev(ptr) ptr
#else /* >= 3.11.0 */
#endif /* >= 3.11.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,13,0))
#if (!(RHEL_RELEASE_CODE && RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,2)))
#define devm_kcalloc(dev, cnt, size, flags) \
	devm_kzalloc(dev, cnt * size, flags)
#endif
#if (!(RHEL_RELEASE_CODE && RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,1)))
static inline void reinit_completion(struct completion *x)
{
	x->done = 0;
}

#ifdef CONFIG_ACPI
#define ACPI_COMPANION(dev)					\
({								\
	struct acpi_device *adev;				\
								\
	acpi_bus_get_device(ACPI_HANDLE(dev), &adev);		\
	adev;							\
})
#else
#define ACPI_COMPANION(dev)	(NULL)
#endif
#endif
#endif /* 3.13.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,14,0))
#if (!(RHEL_RELEASE_CODE && RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,4)))
#define NO_PHY_ATTACH_DIRECT
#endif

#if (!(RHEL_RELEASE_CODE && RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,4)))
#define NO_PHY_INIT_EXPORT
#endif

#if (!(RHEL_RELEASE_CODE && RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,1)))
#ifndef pci_enable_msi_exact
#define pci_enable_msi_exact	__kc_pci_enable_msi_exact
int __kc_pci_enable_msi_range(struct pci_dev *dev, int minvec, int maxvec);
static inline int __kc_pci_enable_msi_exact(struct pci_dev *dev, int nvec)
{
	int rc = __kc_pci_enable_msi_range(dev, nvec, nvec);
	if (rc < 0)
		return rc;
	return 0;
}
#endif
#ifndef pci_enable_msix_range
int __kc_pci_enable_msix_range(struct pci_dev *dev, struct msix_entry *entries,
					  int minvec, int maxvec);
#define pci_enable_msix_range	__kc_pci_enable_msix_range
#endif
#endif /* RHEL < 7.1 */

#if (!(RHEL_RELEASE_CODE && RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,0)) && \
     !(SLE_VERSION_CODE && SLE_VERSION_CODE >= SLE_VERSION(12,0,0)))
#ifndef skb_set_hash

#define PKT_HASH_TYPE_NONE	0
#define PKT_HASH_TYPE_L2	1
#define PKT_HASH_TYPE_L3	2
#define PKT_HASH_TYPE_L4	3

enum _kc_pkt_hash_types {
	_KC_PKT_HASH_TYPE_NONE = PKT_HASH_TYPE_NONE,
	_KC_PKT_HASH_TYPE_L2 = PKT_HASH_TYPE_L2,
	_KC_PKT_HASH_TYPE_L3 = PKT_HASH_TYPE_L3,
	_KC_PKT_HASH_TYPE_L4 = PKT_HASH_TYPE_L4,
};
#define pkt_hash_types         _kc_pkt_hash_types

#define skb_set_hash __kc_skb_set_hash
static inline void __kc_skb_set_hash(struct sk_buff __maybe_unused *skb,
				     u32 __maybe_unused hash,
				     int __maybe_unused type)
{
#ifdef HAVE_SKB_L4_RXHASH
	skb->l4_rxhash = (type == PKT_HASH_TYPE_L4);
#endif
#ifdef NETIF_F_RXHASH
	skb->rxhash = hash;
#endif
}
#endif /* !skb_set_hash */
#endif /* !(RHEL_RELEASE_CODE >= 7.0 && SLE_VERSION_CODE >= 12.0) */
#else
#endif /* 3.14.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,15,0))
#if (!(RHEL_RELEASE_CODE && RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,4))) 
#define PHY_INTERFACE_MODE_XGMII	(PHY_INTERFACE_MODE_SMII+1)

static inline const char *_kc_phy_modes(phy_interface_t interface)
{
	if (interface == PHY_INTERFACE_MODE_XGMII)
		return "xgmii"; 
	else
		return "unknown";
}
#else
static inline const char *_kc_phy_modes(phy_interface_t interface)
{
	return phy_modes(interface);
}
#endif
#else /* 3.15.0 */
static inline const char *_kc_phy_modes(phy_interface_t interface)
{
	return phy_modes(interface);
}
#define HAVE_NET_GET_RANDOM_ONCE
#endif /* 3.15.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,16,0))
#if (!(RHEL_RELEASE_CODE && RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(7,3)))
#define devm_mdiobus_alloc(dev)    mdiobus_alloc()
#endif
#ifndef NETIF_F_GSO_UDP_TUNNEL_CSUM
#define NETIF_F_GSO_UDP_TUNNEL_CSUM 0
#endif
#else /* 3.16.0 */
#endif /* 3.16.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,17,0))
#if (!(RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,2))))
#ifndef timespec64
#define timespec64 timespec
static inline struct timespec64 timespec_to_timespec64(const struct timespec ts)
{
	return ts;
}
static inline struct timespec timespec64_to_timespec(const struct timespec64 ts64)
{
	return ts64;
}
#define timespec64_to_ns timespec_to_ns
#define ns_to_timespec64 ns_to_timespec
#endif
#endif
#endif /* 3.17.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,18,0))
/* RHEL 7.3 backported xmit_more */
#if (RHEL_RELEASE_CODE && RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,3))
#define HAVE_SKB_XMIT_MORE
#endif /* >= RH 7.3 */
#if (!(RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(7,2))))
#define NO_DEVICE_PROPERTY_INTERFACE

#ifndef XGBE_ACPI_DMA_FREQ
#define XGBE_ACPI_DMA_FREQ	"amd,dma-freq"
#endif

#ifndef XGBE_V2_DMA_CLOCK_FREQ
#define XGBE_V2_DMA_CLOCK_FREQ	500000000 
#endif

#ifndef XGBE_V2_PTP_CLOCK_FREQ
#define XGBE_V2_PTP_CLOCK_FREQ	125000000
#endif

#define  device_property_read_u32(dev, propname, val)  _device_property_read_u32(dev, propname, val) 
__attribute__((unused)) static inline int _device_property_read_u32(struct device *dev,
								    const char *propname, u32 *val)
{
	*val = (strcmp(XGBE_ACPI_DMA_FREQ, propname)) ? XGBE_V2_DMA_CLOCK_FREQ : XGBE_V2_PTP_CLOCK_FREQ;
	return 0;
}

#define  device_property_present(dev, propname)  _device_property_present(dev, propname)
__attribute__((unused)) static bool _device_property_present(struct device *dev, const char *propname)
{
	return 0;
}

#define  device_property_read_u32_array(dev, propname, val, nval)   _device_property_read_u32_array(dev, propname, val, nval)
__attribute__((unused)) static int _device_property_read_u32_array(struct device *dev, const char *propname,
								   u32 *val, size_t nval)
{
	return 0;
}

#define device_property_read_u8_array(dev, propname, val, nval)   _device_property_read_u8_array(dev, propname, val, nval)
__attribute__((unused)) static int _device_property_read_u8_array(struct device *dev, const char *propname,
								  u8 *val, size_t nval)
{
	return 0;
}

#define  device_property_read_string(dev, propname, val)  _device_property_read_string(dev, propname, val)
__attribute__((unused)) static int _device_property_read_string(struct device *dev, const char *propname, const char **val)
{
	*val = "xgmii";
	return 0;
}
#endif
#if RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,1))
#define HAVE_SKBUFF_CSUM_LEVEL
#endif /* >= RH 7.1 */
#else /*  3.18.0 */
#define HAVE_SKB_XMIT_MORE
#define HAVE_SKBUFF_CSUM_LEVEL
#endif /* 3.18.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,19,0))
static inline void _kc_napi_complete_done(struct napi_struct *napi,
					  int __always_unused work_done) {
	napi_complete(napi);
}
/* don't use our backport if the distro kernels already have it */
#if (SLE_VERSION_CODE && (SLE_VERSION_CODE < SLE_VERSION(12,3,0))) || \
    (RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(7,5)))
#define napi_complete_done _kc_napi_complete_done
#endif
#if (!(RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(7,1))))
#define __napi_schedule_irqoff	__napi_schedule
#define NO_NDO_FEATURES_CHECK_SUPPORT
#endif

#ifndef dev_warn_once
#define dev_level_once(dev_level, dev, fmt, ...)			\
do {									\
	static bool __print_once __read_mostly;				\
									\
	if (!__print_once) {						\
		__print_once = true;					\
		dev_level(dev, fmt, ##__VA_ARGS__);			\
	}								\
} while (0)

#define dev_err_once(dev, fmt, ...)					\
	dev_level_once(dev_err, dev, fmt, ##__VA_ARGS__)
#define dev_warn_once(dev, fmt, ...)					\
	dev_level_once(dev_warn, dev, fmt, ##__VA_ARGS__)
#endif

#ifndef NETDEV_RSS_KEY_LEN
#define NETDEV_RSS_KEY_LEN (13 * 4)
#endif
#if (!(RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,2))))
#define netdev_rss_key_fill(buffer, len) __kc_netdev_rss_key_fill(buffer, len)
#endif /* RHEL_RELEASE_CODE */
void __kc_netdev_rss_key_fill(void *buffer, size_t len);

#ifndef dma_rmb
#define dma_rmb() rmb()
#endif
#ifndef dma_wmb
#define dma_wmb() wmb()
#endif

#ifndef SKB_ALLOC_NAPI
/* RHEL 7.2 backported napi_alloc_skb and friends */
static inline struct sk_buff *__kc_napi_alloc_skb(struct napi_struct *napi, unsigned int length)
{
	return netdev_alloc_skb_ip_align(napi->dev, length);
}
#define napi_alloc_skb(napi,len) __kc_napi_alloc_skb(napi,len)
#endif /* SKB_ALLOC_NAPI */
#if RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(7,1))
#define HAVE_RXFH_HASHFUNC
#endif /* RHEL > 7.1 */

#else /* 3.19.0 */
#define HAVE_RXFH_HASHFUNC
#endif /* 3.19.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,0,0))
#if (RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(7,1)))
#define HAVE_INCLUDE_LINUX_TIMECOUNTER_H
#endif

#if (!(RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(7,1))))
#ifndef skb_vlan_tag_present
#define skb_vlan_tag_present(__skb)	((__skb)->vlan_tci & VLAN_TAG_PRESENT)
#endif
#ifndef skb_vlan_tag_get
#define skb_vlan_tag_get(__skb)	((__skb)->vlan_tci & ~VLAN_TAG_PRESENT)
#endif
#endif

#else
#define HAVE_INCLUDE_LINUX_TIMECOUNTER_H
#endif /* 4.0.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,1,0))
#if (!(RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,2))))
unsigned int _kc_cpumask_local_spread(unsigned int i, int node);
#define cpumask_local_spread _kc_cpumask_local_spread

#ifdef HAVE_INCLUDE_LINUX_TIMECOUNTER_H
#include <linux/timecounter.h>
#else
#include <linux/clocksource.h>
#endif
#define timecounter_adjtime __kc_timecounter_adjtime
static inline void __kc_timecounter_adjtime(struct timecounter *tc, s64 delta)
{
	tc->nsec += delta;
}
#endif

#if (RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(7,1)))
#define HAVE_PTP_CLOCK_INFO_GETTIME64
#endif
#else
#define HAVE_PTP_CLOCK_INFO_GETTIME64
#endif /* 4.1.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,4,0))
#define DEBUGFS_CREATE_BOOL_U32
#if (!(RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(7,2))))
enum dev_dma_attr {
	DEV_DMA_NOT_SUPPORTED,
	DEV_DMA_NON_COHERENT,
	DEV_DMA_COHERENT,
};

#define device_get_dma_attr(dev)  _device_get_dma_attr(dev)
__attribute__((unused)) static enum dev_dma_attr _device_get_dma_attr(struct device *dev)
{
	return DEV_DMA_COHERENT;
}
#endif
#else /* < 4.4.0 */
#endif /* 4.4.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,5,0))
#if (!(RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(7,2))))
static inline int skb_inner_transport_offset(const struct sk_buff *skb)
{
	return skb_inner_transport_header(skb) - skb->data;
}
#endif
#else /* < 4.5.0 */
#endif /* 4.5.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,8,0))
#else
#define HAVE_UDP_ENC_RX_OFFLOAD
#endif /* 4.8.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,9,0))
#if (!(RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(7,3))))
#ifdef ETHTOOL_GLINKSETTINGS
#define ETHTOOL_LINK_MODE_2500baseT_Full_BIT	ETHTOOL_LINK_MODE_2500baseX_Full_BIT
#define ETHTOOL_LINK_MODE_1000baseX_Full_BIT	ETHTOOL_LINK_MODE_1000baseT_Full_BIT
#define ETHTOOL_LINK_MODE_10000baseCR_Full_BIT	ETHTOOL_LINK_MODE_10000baseT_Full_BIT
#define ETHTOOL_LINK_MODE_10000baseSR_Full_BIT	ETHTOOL_LINK_MODE_10000baseT_Full_BIT
#define ETHTOOL_LINK_MODE_10000baseLR_Full_BIT	ETHTOOL_LINK_MODE_10000baseT_Full_BIT
#define ETHTOOL_LINK_MODE_10000baseLRM_Full_BIT	ETHTOOL_LINK_MODE_10000baseT_Full_BIT
#define ETHTOOL_LINK_MODE_10000baseER_Full_BIT	ETHTOOL_LINK_MODE_10000baseT_Full_BIT

#define NO_FULL_SUPPORT_ETHTOOL_LINK_MODE
#endif
#endif
#endif /* 4.9.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,10,0))
/* SLES 12.3 and RHEL 7.5 backported this interface */
#if (!SLE_VERSION_CODE && !RHEL_RELEASE_CODE) || \
    (SLE_VERSION_CODE && (SLE_VERSION_CODE < SLE_VERSION(12,3,0))) || \
    (RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(7,5)))
static inline bool _kc_napi_complete_done2(struct napi_struct *napi,
					   int __always_unused work_done)
{
	/* it was really hard to get napi_complete_done to be safe to call
	 * recursively without running into our own kcompat, so just use
	 * napi_complete
	 */
	napi_complete(napi);

	/* true means that the stack is telling the driver to go-ahead and
	 * re-enable interrupts
	 */
	return true;
}

#if (!(RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,4))))
/**
 *   phy_aneg_done - return auto-negotiation status
 *   @phydev: target phy_device struct
 *   
 *   Description: Reads the status register and returns 0 either if
 *   auto-negotiation is incomplete, or if there was an error.
 *   Returns BMSR_ANEGCOMPLETE if auto-negotiation is done.
 *   
 */
static inline int phy_aneg_done(struct phy_device *phydev)
{
	int retval;

	retval = phy_read(phydev, MII_BMSR);

	return (retval < 0) ? retval : (retval & BMSR_ANEGCOMPLETE);
}
#endif

#define NO_PCI_ALLOC_IRQ_VECTOR

#ifdef napi_complete_done
#undef napi_complete_done
#endif
#define napi_complete_done _kc_napi_complete_done2
#endif /* sles and rhel exclusion for < 4.10 */
#if (RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,5)))
#define HAVE_RHEL7_EXTENDED_MIN_MAX_MTU
#define HAVE_NETDEVICE_MIN_MAX_MTU
#endif
#else /* >= 4.10 */
#define HAVE_NETDEVICE_MIN_MAX_MTU
#endif /* 4.10.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,11,0))
#if ((SLE_VERSION_CODE && (SLE_VERSION_CODE >= SLE_VERSION(12,3,0))) || \
     (RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,5))))
#define HAVE_VOID_NDO_GET_STATS64
#endif /* (SLES >= 12.3.0) || (RHEL >= 7.5) */
#else /* > 4.11 */
#define HAVE_VOID_NDO_GET_STATS64
#endif /* 4.11.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,13,0))
#else /* > 4.13 */
#define HAVE_HWTSTAMP_FILTER_NTP_ALL
#define HAVE_NDO_SETUP_TC_CHAIN_INDEX
#endif /* 4.13.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,14,0))
#ifdef ETHTOOL_GLINKSETTINGS
#ifndef ethtool_link_ksettings_del_link_mode
#define ethtool_link_ksettings_del_link_mode(ptr, name, mode)		\
			__clear_bit(ETHTOOL_LINK_MODE_ ## mode ## _BIT, (ptr)->link_modes.name)
#endif
#endif /* ETHTOOL_GLINKSETTINGS */

#ifndef NETIF_F_RX_UDP_TUNNEL_PORT
#define NETIF_F_RX_UDP_TUNNEL_PORT 0
#endif

#if (RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,5)))
#define HAVE_NDO_SETUP_TC_REMOVE_TC_TO_NETDEV
#define HAVE_RHEL7_NETDEV_OPS_EXT_NDO_SETUP_TC
#endif

#define TIMER_DATA_TYPE		unsigned long
#define TIMER_FUNC_TYPE		void (*)(TIMER_DATA_TYPE)
	
#define timer_setup(timer, callback, flags)				\
		__setup_timer((timer), (TIMER_FUNC_TYPE)(callback),		\
			      (TIMER_DATA_TYPE)(timer), (flags))

#define from_timer(var, callback_timer, timer_fieldname) \
	container_of(callback_timer, typeof(*var), timer_fieldname)

#else /* > 4.14 */
#define HAVE_NDO_SETUP_TC_REMOVE_TC_TO_NETDEV
#endif /* 4.14.0 */

/*****************************************************************************/
#ifndef ETHTOOL_GLINKSETTINGS

#define __ETHTOOL_LINK_MODE_MASK_NBITS 32
#define ETHTOOL_LINK_MASK_SIZE BITS_TO_LONGS(__ETHTOOL_LINK_MODE_MASK_NBITS)

/**
 * struct ethtool_link_ksettings
 * @link_modes: supported and advertising, single item arrays
 * @link_modes.supported: bitmask of supported link speeds
 * @link_modes.advertising: bitmask of currently advertised speeds
 * @base: base link details
 * @base.speed: current link speed
 * @base.port: current port type
 * @base.duplex: current duplex mode
 * @base.autoneg: current autonegotiation settings
 *
 * This struct and the following macros provide a way to support the old
 * ethtool get/set_settings API on older kernels, but in the style of the new
 * GLINKSETTINGS API.  In this way, the same code can be used to support both
 * APIs as seemlessly as possible.
 *
 * It should be noted the old API only has support up to the first 32 bits.
 */
struct ethtool_link_ksettings {
	struct {
		u32 speed;
		u8 port;
		u8 duplex;
		u8 autoneg;
		u8 phy_address;
	} base;
	struct {
		unsigned long supported[ETHTOOL_LINK_MASK_SIZE];
		unsigned long advertising[ETHTOOL_LINK_MASK_SIZE];
		unsigned long lp_advertising[ETHTOOL_LINK_MASK_SIZE];
	} link_modes;
};

#define SUPPORTED_1000baseX_Full	SUPPORTED_1000baseT_Full
#define SUPPORTED_10000baseSR_Full	SUPPORTED_10000baseT_Full
#define SUPPORTED_10000baseER_Full	SUPPORTED_10000baseT_Full
#define SUPPORTED_10000baseLRM_Full	SUPPORTED_10000baseT_Full
#define SUPPORTED_10000baseLR_Full	SUPPORTED_10000baseT_Full
#define SUPPORTED_10000baseCR_Full	SUPPORTED_10000baseT_Full
#define SUPPORTED_2500baseT_Full	SUPPORTED_2500baseX_Full

#define ADVERTISED_1000baseX_Full	ADVERTISED_1000baseT_Full
#define ADVERTISED_10000baseSR_Full	ADVERTISED_10000baseT_Full
#define ADVERTISED_10000baseER_Full	ADVERTISED_10000baseT_Full
#define ADVERTISED_10000baseLRM_Full	ADVERTISED_10000baseT_Full
#define ADVERTISED_10000baseLR_Full	ADVERTISED_10000baseT_Full
#define ADVERTISED_10000baseCR_Full	ADVERTISED_10000baseT_Full
#define ADVERTISED_2500baseT_Full	ADVERTISED_2500baseX_Full

#define ETHTOOL_LINK_NAME_advertising(mode) ADVERTISED_ ## mode
#define ETHTOOL_LINK_NAME_lp_advertising(mode) ADVERTISED_ ## mode
#define ETHTOOL_LINK_NAME_supported(mode) SUPPORTED_ ## mode
#define ETHTOOL_LINK_NAME(name) ETHTOOL_LINK_NAME_ ## name
#define ETHTOOL_LINK_CONVERT(name, mode) ETHTOOL_LINK_NAME(name)(mode)

/**
 * ethtool_link_ksettings_zero_link_mode
 * @ptr: ptr to ksettings struct
 * @name: supported or advertising
 */
#define ethtool_link_ksettings_zero_link_mode(ptr, name)\
	(*((ptr)->link_modes.name) = 0x0)

/**
 * ethtool_link_ksettings_add_link_mode
 * @ptr: ptr to ksettings struct
 * @name: supported or advertising
 * @mode: link mode to add
 */
#define ethtool_link_ksettings_add_link_mode(ptr, name, mode)\
	(*((ptr)->link_modes.name) |= (typeof(*((ptr)->link_modes.name)))ETHTOOL_LINK_CONVERT(name, mode))

/**
 * ethtool_link_ksettings_del_link_mode
 * @ptr: ptr to ksettings struct
 * @name: supported or advertising
 * @mode: link mode to delete
 */
#define ethtool_link_ksettings_del_link_mode(ptr, name, mode)\
	(*((ptr)->link_modes.name) &= ~(typeof(*((ptr)->link_modes.name)))ETHTOOL_LINK_CONVERT(name, mode))

/**
 * ethtool_link_ksettings_test_link_mode
 * @ptr: ptr to ksettings struct
 * @name: supported or advertising
 * @mode: link mode to add
 */
#define ethtool_link_ksettings_test_link_mode(ptr, name, mode)\
	(!!(*((ptr)->link_modes.name) & ETHTOOL_LINK_CONVERT(name, mode)))

#endif /* !ETHTOOL_GLINKSETTINGS */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,15,0))
#if ((RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,6))) || \
     (SLE_VERSION_CODE && (SLE_VERSION_CODE >= SLE_VERSION(15,1,0))))

#else /* RHEL >= 7.6 || SLES >= 15.1 */
#define TC_SETUP_QDISC_MQPRIO TC_SETUP_MQPRIO
#endif /* !(RHEL >= 7.6) && !(SLES >= 15.1) */
#else /* >= 4.15 */

#endif /* 4.15.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,19,0))

#else /* >= 4.19.0 */
#define HAVE_CRC32POLY_H
#endif /* 4.19.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5,0,0))
#if (!(RHEL_RELEASE_CODE && RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(8,0)))
#if (LINUX_VERSION_CODE < KERNEL_VERSION(4,20,0))
static inline void _kc_phy_support_gbit(struct phy_device *phydev)
{
        phydev->supported = PHY_GBIT_FEATURES;
}

static inline void _kc_phy_support_asym_pause(struct phy_device *phydev)
{
        phydev->supported |= SUPPORTED_Pause | SUPPORTED_Asym_Pause;
        phydev->advertising = phydev->supported;
}
#else
static inline void _kc_phy_support_gbit(struct phy_device *phydev)
{
        phydev->supported = PHY_10BT_FEATURES |
                            PHY_100BT_FEATURES | PHY_1000BT_FEATURES;
}

static inline void _kc_phy_support_asym_pause(struct phy_device *phydev)
{
        phy_support_asym_pause(phydev);
}
#endif /* < 4.20.0 */
#else
#define PHY_DEVICE_SUPPORT_LINKMODE
#define HAVE_LINKMODE_ADV_TO_LCL_ADVT
static inline void _kc_phy_support_gbit(struct phy_device *phydev)
{
	linkmode_zero(phydev->supported);
	linkmode_set_bit_array(phy_10_100_features_array,
			       ARRAY_SIZE(phy_10_100_features_array),
			       phydev->supported);
	linkmode_set_bit_array(phy_gbit_features_array,
			       ARRAY_SIZE(phy_gbit_features_array),
			       phydev->supported);
}
static inline void _kc_phy_support_asym_pause(struct phy_device *phydev)
{
	phy_support_asym_pause(phydev);
}
#endif /* !(RHEL_RELEASE_CODE && RHEL > RHEL(8,0)) */
#else /* >= 5.0.0 */
#define PHY_DEVICE_SUPPORT_LINKMODE
#define HAVE_LINKMODE_ADV_TO_LCL_ADVT
static inline void _kc_phy_support_gbit(struct phy_device *phydev)
{
	linkmode_zero(phydev->supported);
	linkmode_set_bit_array(phy_10_100_features_array,
			       ARRAY_SIZE(phy_10_100_features_array),
			       phydev->supported);
	linkmode_set_bit_array(phy_gbit_features_array,
			       ARRAY_SIZE(phy_gbit_features_array),
			       phydev->supported);
}
static inline void _kc_phy_support_asym_pause(struct phy_device *phydev)
{
	phy_support_asym_pause(phydev);
}
#endif /* 5.0.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5,2,0))
#ifdef HAVE_SKB_XMIT_MORE
#if (!(RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(8,2))))
#define netdev_xmit_more()	(packet->skb->xmit_more)
#endif
#else
#define netdev_xmit_more()	(0)
#endif /* HAVE_SKB_XMIT_MORE */
#else /* >= 5.2.0 */
#endif /* 5.2.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5,4,0))
#ifndef fallthrough
#define fallthrough	do {} while (0)
#endif
#endif

/*****************************************************************************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5,6,0))
#if (RHEL_RELEASE_CODE && (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(8,3)))
#define HAVE_TX_TIMEOUT_TXQUEUE
#endif
#else /* >= 5.6.0 */
#define HAVE_TX_TIMEOUT_TXQUEUE
#endif /* 5.6.0 */

/*****************************************************************************/
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5,9,0))
#define HAVE_XGBE_UDP_TUNNEL_NIC_INFO
#else /* <= 5.12.0 */
#endif

/*****************************************************************************/
#if(LINUX_VERSION_CODE >= KERNEL_VERSION(5,5,0))
#ifndef FIELD_SIZEOF
#define FIELD_SIZEOF sizeof_field
#endif
#endif

/*****************************************************************************/
#if(LINUX_VERSION_CODE >= KERNEL_VERSION(5,7,0))
#define HAVE_XGBE_COALESCE_PARAMS
#endif

/*****************************************************************************/
#if(LINUX_VERSION_CODE >= KERNEL_VERSION(5,15,0))
#define XGBE_COALESCE_GET_SET_ADD_PARAMS
#endif

/*****************************************************************************/
#if(LINUX_VERSION_CODE >= KERNEL_VERSION(5,17,0))
#define XGBE_RINGPARAM_GET_SET_ADD_PARAMS
#endif

#endif /* __KVER_COMPAT_H__ */
